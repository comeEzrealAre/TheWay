package com.example.myapplication

object Routes {
    var screenLogin = "screen_Login"
    var screenHome  = "screen_Home"
    var screenMap   = "screen_Map"
}